<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

        // Controller construct
        // loads all resources for class
        function Welcome(){
            parent::__construct();
            
            // load libraries
            $this->load->library('common/common_lib');
        }
        
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 */
	public function index()
	{
            $this->common_lib->home_header();
            $this->load->view('welcome_message');
            $this->common_lib->home_footer();
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
