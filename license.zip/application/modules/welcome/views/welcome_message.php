
<div class="container" id="home_container">

    <div class="row">
        <div class="span16">
            <img src="<?=base_url()?>assets/images/home/logo.png"><br><br><br><br>
            <div class="row content">
                <div class="span6 offset2">
                    <div class="welcome_h">
                        Welcome
                        <div id="body">
                        ClassVibe is an online directory
                        of classes for university students.
                        Study together, not harder.
                        </div>
                    </div>
                </div>
                <div class="span1"><img src="<?=base_url()?>assets/images/home/Divider.png"></div>
                <div class="span6">
                    <div class="signup_h">
                        Signup
                        <div id="body">
                            <input type="email" placeholder="Email"></input><br>
                            <input type="submit" class="btn green asenine" value="Continue">
                        </div>
                    </div>
                   
                </div>
            </div>
            <!--<input type="submit" class="btn primary" value="Continue">-->
        </div>
    </div>

</div>
