<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Classvibe</title>
        
        <link rel="stylesheet/less" href="<?=base_url()?>assets/css/bootstrap.less" media="all">
        <?=display_js(array('less-1.1.5.min.js'))?>
        <link rel="stylesheet" href="<?=base_url()?>assets/css/fonts.css">
    
        

     
        <style>

            html{
                background:url('<?=base_url()?>assets/images/home/bg.png') no-repeat;
                background-size:100%;
                font-family: 'AsenineRegular';
            }
            body{
                background:transparent;
            }
        </style>
        
</head>
<body>

