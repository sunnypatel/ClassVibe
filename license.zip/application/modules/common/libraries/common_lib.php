<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_lib {

    function Common_lib()
    {
        //constructor for the common_lib
        $CI =& get_instance();
        
    }
    
    // create homepage header
    public function home_header(){
        // create a CI instance for this library
        $CI =& get_instance();
        // load assets spark
        $CI->load->spark('assets/0.6.3');
        // load homepage view page w/assets
        $CI->load->view('common/home_header');
        
    }
    
    // create homepage footer
    public function home_footer(){
        // create a CI instance for this library
        $CI =& get_instance();
        // load assets spark
        $CI->load->spark('assets/0.6.3');
        // load homepage view page w/assets
        $CI->load->view('common/home_footer');
        
    }

    // create default header
    public function header(){
        // create a CI instance for this library
        $CI =& get_instance();
        // load assets spark
        $CI->load->spark('assets/0.6.3');
        // load homepage view page w/assets
        $CI->load->view('common/header');
        
    }        
    
    // create default footer
    public function footer(){
        // create a CI instance for this library
        $CI =& get_instance();
        // load assets spark
        $CI->load->spark('assets/0.6.3');
        // load homepage view page w/assets
        $CI->load->view('common/footer');
        
    }    
}