<?php

// Load the assets library when loading the spark
$autoload['config']    = array('assets');
$autoload['helper']    = array('url', 'file', 'directory', 'string', 'assets');
$autoload['libraries'] = array('assets');
